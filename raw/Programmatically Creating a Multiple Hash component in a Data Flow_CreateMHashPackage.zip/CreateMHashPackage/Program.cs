﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.SqlServer.Dts.Design;
using Microsoft.SqlServer.Dts.Pipeline;
using Microsoft.SqlServer.Dts.Pipeline.Wrapper;
using Microsoft.SqlServer.Dts.Runtime.Wrapper;
using Microsoft.SqlServer.Dts.Runtime;
using Martin.SQLServer.Dts;


namespace CreateMHashPackage
{
    class Program
    {
        static void Main(string[] args)
        {
            // Setup variables for the SSIS app component.
            Microsoft.SqlServer.Dts.Runtime.Application app = new Microsoft.SqlServer.Dts.Runtime.Application();
            // Create a new Package in memory
            Microsoft.SqlServer.Dts.Runtime.Package package = new Microsoft.SqlServer.Dts.Runtime.Package();
            
            // Add a Pipeline task and name it.
            Executable exec = package.Executables.Add("STOCK:PipelineTask");
            Microsoft.SqlServer.Dts.Runtime.TaskHost thMainPipe = exec as Microsoft.SqlServer.Dts.Runtime.TaskHost;
            MainPipe dataFlowTask = thMainPipe.InnerObject as MainPipe;
            thMainPipe.Name = "Multiple Hash Pipeline";

            // Create a flat file source
            ConnectionManager flatFileConnectionManager = package.Connections.Add("FLATFILE");
            flatFileConnectionManager.Properties["Format"].SetValue(flatFileConnectionManager, "Delimited");
            flatFileConnectionManager.Properties["Name"].SetValue(flatFileConnectionManager, "Flat File Connection");
            flatFileConnectionManager.Properties["ConnectionString"].SetValue(flatFileConnectionManager, @".\SampleSourceFile.txt");
            flatFileConnectionManager.Properties["ColumnNamesInFirstDataRow"].SetValue(flatFileConnectionManager, false);
            flatFileConnectionManager.Properties["HeaderRowDelimiter"].SetValue(flatFileConnectionManager, "\r\n");
            flatFileConnectionManager.Properties["TextQualifier"].SetValue(flatFileConnectionManager, "\"");
            flatFileConnectionManager.Properties["DataRowsToSkip"].SetValue(flatFileConnectionManager, 0);
            flatFileConnectionManager.Properties["Unicode"].SetValue(flatFileConnectionManager, false);
            flatFileConnectionManager.Properties["CodePage"].SetValue(flatFileConnectionManager, 1252);

            // Create two columns in the flat file
            IDTSConnectionManagerFlatFile100 flatFileConnection = flatFileConnectionManager.InnerObject as IDTSConnectionManagerFlatFile100;
            IDTSConnectionManagerFlatFileColumn100 rowTypeColumn = flatFileConnection.Columns.Add();
            rowTypeColumn.ColumnDelimiter = "|";
            rowTypeColumn.ColumnType = "Delimited";
            rowTypeColumn.DataType = DataType.DT_STR;
            rowTypeColumn.DataPrecision = 0;
            rowTypeColumn.DataScale = 0;
            rowTypeColumn.MaximumWidth = 10;
            ((IDTSName100)rowTypeColumn).Name = "rowType";
            IDTSConnectionManagerFlatFileColumn100 dataColumn = flatFileConnection.Columns.Add();
            dataColumn.ColumnDelimiter = "\r\n";
            dataColumn.ColumnType = "Delimited";
            dataColumn.DataType = DataType.DT_TEXT;
            dataColumn.DataPrecision = 0;
            dataColumn.DataScale = 0;
            ((IDTSName100)dataColumn).Name = "Data";

            // Create the Flat File Input, name it, and assign it to the Flat File connection.
            IDTSComponentMetaData100 flatFile = dataFlowTask.ComponentMetaDataCollection.New();
            flatFile.Name = "Input Flat File";
            flatFile.ComponentClassID = app.PipelineComponentInfos["Flat File Source"].CreationName;
            CManagedComponentWrapper flatFileInstance = flatFile.Instantiate();
            flatFileInstance.ProvideComponentProperties();
            // Connect to the Flat File Connection
            flatFile.RuntimeConnectionCollection[0].ConnectionManager = DtsConvert.GetExtendedInterface(flatFileConnectionManager);
            flatFile.RuntimeConnectionCollection[0].ConnectionManagerID = flatFileConnectionManager.ID;
            flatFileInstance.AcquireConnections(null);
            flatFileInstance.ReinitializeMetaData();
            flatFileInstance.ReleaseConnections();
            // Enable retention of null values.
            flatFile.CustomPropertyCollection["RetainNulls"].Value = true;



            // Create the Multiple Hash Component, and name it.
            IDTSComponentMetaData100 multipleHash = dataFlowTask.ComponentMetaDataCollection.New();
            multipleHash.Name = "Multiple Hash";
            multipleHash.ComponentClassID = typeof(Martin.SQLServer.Dts.MultipleHash).AssemblyQualifiedName;
            CManagedComponentWrapper multipleHashInstance = multipleHash.Instantiate();
            multipleHashInstance.ProvideComponentProperties();

            // Set the properties for Multiple Hash.  This is optional if the defaults aren't suitable.
            // The defaults are 
            // Safe Null Handling = true
            // Enable Multiple Threading = None
            // Milliseconds = true
            multipleHash.CustomPropertyCollection[Utility.SafeNullHandlingPropName].Value = MultipleHash.SafeNullHandling.True;
            multipleHash.CustomPropertyCollection[Utility.MultipleThreadPropName].Value = MultipleHash.MultipleThread.Auto;
            multipleHash.CustomPropertyCollection[Utility.HandleMillisecondPropName].Value = MultipleHash.MillisecondHandling.True;

            // Attach the Flat File Source to the Multiple Hash
            IDTSPath100 path = dataFlowTask.PathCollection.New();
            path.AttachPathAndPropagateNotifications(flatFile.OutputCollection[0],multipleHash.InputCollection[0]);

            // Tick all the input columns, so that they can be selected for hashing.
            IDTSVirtualInput100 virtualInput = multipleHash.InputCollection[0].GetVirtualInput();
            foreach(IDTSVirtualInputColumn100 viColumn in virtualInput.VirtualInputColumnCollection)
            {
                IDTSInputColumn100 inputColumn = multipleHash.InputCollection[0].InputColumnCollection.New();
                inputColumn.Name = viColumn.Name;
                inputColumn.UsageType = DTSUsageType.UT_READONLY;
                inputColumn.LineageID = viColumn.LineageID;
            }

            #region Create Output Column (Repeat for all output columns)
            // Create an Output Column.  The 0 just puts this column at the start of the output column list.
            IDTSOutputColumn100 outputColumn = multipleHashInstance.InsertOutputColumnAt(multipleHash.OutputCollection[0].ID, 0, "SHA1HashAllByName", "SHA1Hash of all columns sorted by name");
            // Assign it to be SHA1 Hash, and set the data type  (Just change tht SHA1 to a different available hash on the following two lines for different hashes.)
            outputColumn.CustomPropertyCollection[Utility.HashTypePropName].Value = MultipleHash.HashTypeEnumerator.SHA1;
            Utility.SetOutputColumnDataType(MultipleHash.HashTypeEnumerator.SHA1, outputColumn);

            // Get a list of all the input columns sorted by name. (The sort is entirely up to you.)
            SortedDictionary<String, int> inputColumnList = new SortedDictionary<string, int>();
            foreach (IDTSInputColumn100 inputColumn in multipleHash.InputCollection[0].InputColumnCollection)
            {
                inputColumnList.Add(inputColumn.Name, inputColumn.LineageID);
            }

            // Generate a list of the columns to be hashed.
            String inputLineageIDs = String.Empty;

            // Format the data for the input column list.  MUST be formatted as #lineageID,#lineageID,#lineageID...
            // The order of the lineage id's sets the order that the columns are hashed in.
            foreach(int lineageID in inputColumnList.Values)
            {
                if (String.IsNullOrEmpty(inputLineageIDs))
                {
                    inputLineageIDs = String.Format("#{0}", lineageID);
                }
                else
                {
                    inputLineageIDs += String.Format(",#{0}", lineageID);
                }
            }
            // Assign the custom property that contains the input column list for this output column.
            outputColumn.CustomPropertyCollection[Utility.InputColumnLineagePropName].Value = inputLineageIDs;
            #endregion


            // To Do, connect the output up to a destination.
            package.Variables.Add("RowsetVariable", false, "User", new Object());
            Microsoft.SqlServer.Dts.Runtime.Variable SSISVariable = package.Variables["RowsetVariable"];

            IDTSComponentMetaData100 recordSet = dataFlowTask.ComponentMetaDataCollection.New();
            recordSet.ComponentClassID = app.PipelineComponentInfos["Recordset Destination"].CreationName;
            recordSet.ValidateExternalMetadata = true;
            recordSet.Name = "Recordset Destination";
            CManagedComponentWrapper recordSetInstance = recordSet.Instantiate();
            recordSetInstance.ProvideComponentProperties();
            recordSet.CustomPropertyCollection["VariableName"].Value = SSISVariable.Name;

            // Attach Multiple Hash to the Record Set Destination
            IDTSPath100 mhToRSpath = dataFlowTask.PathCollection.New();
            mhToRSpath.AttachPathAndPropagateNotifications(multipleHash.OutputCollection[0], recordSet.InputCollection[0]);

            // Tick all the input columns, so that they can be selected for output.
            virtualInput = recordSet.InputCollection[0].GetVirtualInput();
            foreach (IDTSVirtualInputColumn100 viColumn in virtualInput.VirtualInputColumnCollection)
            {
                IDTSInputColumn100 inputColumn = recordSet.InputCollection[0].InputColumnCollection.New();
                inputColumn.Name = viColumn.Name;
                inputColumn.UsageType = DTSUsageType.UT_READONLY;
                inputColumn.LineageID = viColumn.LineageID;
            }

            // Save the package
            app.SaveToXml(".\\test.dtsx", package, null);

        }
    }
}
